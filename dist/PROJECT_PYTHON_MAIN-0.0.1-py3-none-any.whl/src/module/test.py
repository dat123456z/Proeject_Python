from giaodien.gdnew import *

print(car_data)